import requests
import os
from colorama import Fore, Style, init

# Инициализация colorama
init(autoreset=True)

def print_header():
    # Зелёный текст в начале
    print(Fore.GREEN + r"  ______ _    _ __  ______     __")
    print(Fore.GREEN + r" |  ____| |  | /_ |/ __ \ \   / /")
    print(Fore.GREEN + r" | |__  | |__| || | |  | \ \_/ / ")
    print(Fore.GREEN + r" |  __| |  __  || | |  | |\   /  ")
    print(Fore.GREEN + r" | |____| |  | || | |__| | | |   ")
    print(Fore.GREEN + r" |______|_|  |_||_|\____/  |_|   ")
    print(Fore.GREEN + r"                                 ")
    print(Style.BRIGHT + "JSON 1.4 by EH1OY")
    print(Style.BRIGHT + "                                 ")
    
def print_done_message():
    # Зелёное сообщение в конце
    print(Fore.GREEN + "+" + "-" * 30 + "+")
    print(Fore.GREEN + "|          ГОТОВО!            |")
    print(Fore.GREEN + "+" + "-" * 30 + "+")

def main():
    print_header()
    
    # Ввод базового URL
    base_url = input("Введите URL (BLACK RUSSIA - http://api.blackrussia.online/client/ KING RUSSIA - https://cdn.advens.cloud/_/4a0b65f6bc0530466038bc71184ab00b/): ").strip()
    
    # Ввод User-Agent
    user_agent = input("Введите User-Agent (BLACK RUSSIA - MOl9ISIvsVFgqqVgDIBpVmf KING RUSSIA - Ничего не писать): ").strip() or "MOl9ISIvsVFgqqVgDIBpVmf"
    headers = {"User-Agent": user_agent}

    # Ввод папки для сохранения
    save_folder = input(r"Введите путь к папке для сохранения файлов (Пример: E:\json):").strip()
    if not os.path.exists(save_folder):
        print(Fore.YELLOW + f"Папка {save_folder} не существует. Создаём её...")
        os.makedirs(save_folder, exist_ok=True)

    # Ввод пути к файлу со списком файлов
    file_list_path = input("Введите путь к файлу со списком файлов (BLACK RUSSIA - ваш путь к папке py/blackrussia.txt KING RUSSIA - ваш путь к папке py/kingrussia.txt): ").strip()
    if not os.path.isfile(file_list_path):
        print(Fore.RED + "Файл списка не найден.")
        return

    # Чтение списка файлов
    with open(file_list_path, "r") as file_list:
        files = file_list.read().splitlines()

    # Загрузка каждого файла по очереди
    for file_name in files:
        url = f"{base_url}{file_name}"
        try:
            response = requests.get(url, headers=headers)
            response.raise_for_status()  # Проверка успешности запроса

            # Путь для сохранения файла
            file_path = os.path.join(save_folder, file_name)
            
            # Сохранение файла
            with open(file_path, "wb") as f:
                f.write(response.content)
            print(Fore.GREEN + f"Файл {file_name} успешно загружен в {file_path}.")
        except requests.exceptions.RequestException as e:
            print(Fore.RED + f"Ошибка при загрузке {file_name}: {e}")

    print_done_message()
    input("Нажмите Enter, чтобы закрыть программу...")

if __name__ == "__main__":
    main()
