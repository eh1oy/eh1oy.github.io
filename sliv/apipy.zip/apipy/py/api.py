import os
import json
import requests
import zlib
from colorama import Fore, Style, init

init(autoreset=True)

def calculate_crc32(file_path):
    """Вычисляет CRC32 хеш файла."""
    crc32_hash = 0
    try:
        with open(file_path, 'rb') as f:
            while chunk := f.read(8192):
                crc32_hash = zlib.crc32(chunk, crc32_hash)
    except Exception as e:
        print(Fore.RED + f"Ошибка при вычислении CRC32 для {file_path}: {e}")
        return None
    return str(crc32_hash & 0xFFFFFFFF)

def download_file(url, path, user_agent):
    """Скачивает файл с заданного URL и сохраняет его по указанному пути."""
    try:
        headers = {'User-Agent': user_agent} if user_agent else {}
        response = requests.get(url, headers=headers, stream=True)
        response.raise_for_status()

        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, 'wb') as f:
            for data in response.iter_content(chunk_size=8192):
                f.write(data)
        print(f"Файл загружен: {path}")

    except requests.exceptions.HTTPError as err:
        print(f"Ошибка HTTP: {err}")
    except Exception as e:
        print(f"Ошибка при загрузке файла: {e}")

def download_json(json_url, download_folder, web_host_url, user_agent):
    """Скачивает JSON-файл и загружает файлы по данным из него."""
    try:
        headers = {'User-Agent': user_agent} if user_agent else {}
        response = requests.get(json_url, headers=headers)
        response.raise_for_status()
        json_data = response.json()

        for file_info in json_data:
            name = file_info['name']
            path = file_info['path']
            full_path = os.path.join(download_folder, path, name)
            remote_file_url = f"{web_host_url}/{path}{name}"
            download_file(remote_file_url, full_path, user_agent)

    except requests.exceptions.HTTPError as err:
        print(f"Ошибка HTTP: {err}")
    except json.JSONDecodeError as e:
        print(f"Ошибка при декодировании JSON: {e}")
    except Exception as e:
        print(f"Ошибка при загрузке JSON: {e}")

def create_api_json(folder_path, save_path, start_date):
    """Создает api.json с информацией о файлах в указанной папке."""
    if not os.path.exists(folder_path):
        print(Fore.RED + "Ошибка: указанная папка не существует.")
        return

    files_info = []
    counter = start_date  # Теперь это число, а не строка

    for root, dirs, files in os.walk(folder_path):
        for file in files:
            file_path = os.path.join(root, file)
            path = os.path.relpath(root, folder_path).replace("\\", "/")
            
            # Вычисляем CRC32
            crc32_hash = calculate_crc32(file_path)
            if crc32_hash is None:
                continue  # Пропускаем файл при ошибке

            # Формируем путь
            if path == ".":
                path = ""
            else:
                path += "/"

            file_info = {
                "date": counter,  # Убраны кавычки - теперь это число
                "hash": crc32_hash,
                "name": file,
                "path": path,
                "size": os.path.getsize(file_path)
            }
            files_info.append(file_info)
            counter += 1  # Увеличиваем счётчик как число

    try:
        with open(save_path, 'w') as outfile:
            json.dump(files_info, outfile, indent=4)
        print(Fore.GREEN + f"api.json создан: {save_path}")
    except Exception as e:
        print(Fore.RED + f"Ошибка при сохранении api.json: {e}")

def display_done_message():
    """Отображает сообщение о завершении процесса в виде рамки."""
    done_message = [
        "████████████████████████",
        "█                      █",
        "█        Готово        █",
        "█                      █",
        "████████████████████████"
    ]
    for line in done_message:
        print(Fore.GREEN + line)

def main():
    print(Fore.GREEN + r""" 
  ______ _    _ __  ______     __
 |  ____| |  | /_ |/ __ \ \   / /
 | |__  | |__| || | |  | \ \_/ / 
 |  __| |  __  || | |  | |\   /  
 | |____| |  | || | |__| | | |   
 |______|_|  |_||_|\____/  |_|   
""")
    print(Style.RESET_ALL)
    print("Добро пожаловать! Версия программы 4.0. Создал EH1OY (eh1oy.rf.gd)")
    print("")

    print("Выберите действие (1 или 2):")
    print("1 - Для создания api.json")
    print("2 - Для скачивания файлов по api.json")
    action = input("Выберите (1 или 2): ")
    
    if action == '1':
        folder_path = input("Введите путь к папке для создания api.json (Пример: E:/cache): ")
        save_path = input("Введите путь для сохранения api.json (Пример: E:/cache/api.json): ")
        start_date = int(input("Введите начальное значение для поля date (Пример: 4): "))
        create_api_json(folder_path, save_path, start_date)
    
    elif action == '2':
        json_url = input("Введите URL к JSON-файлу (Пример: https://example.com/api.json):    ")
        web_host_url = input("Введите URL веб-хостинга для загрузки файлов (Пример: https://example.com/    его можно узнать в download.json): ")
        download_folder = input("Введите путь к папке для загрузки (Пример: E:/output): ")
        user_agent = input("Введите User-Agent (или оставьте пустым для значения по умолчанию): ")
        download_json(json_url, download_folder, web_host_url, user_agent)
    else:
        print("Некорректный ввод. Пожалуйста, выберите 1 или 2.")

    display_done_message()
    input("Нажмите Enter, чтобы выйти.")

if __name__ == "__main__":
    main()